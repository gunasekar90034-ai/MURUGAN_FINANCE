WEEKLY FINANCE ANDROID APP - SOURCE PROJECT

முக்கியம்:
இது Android Studio மூலம் APK உருவாக்குவதற்கான source project. APK file ஏற்கனவே build செய்யப்பட்டதாகக் கருத வேண்டாம்.

APK உருவாக்க:
1. கணினியில் Android Studio நிறுவவும்.
2. இந்த ZIP-ஐ extract செய்யவும்.
3. Android Studio-வில் WeeklyFinance folder-ஐ Open செய்யவும்.
4. Gradle sync முடியும் வரை காத்திருக்கவும்.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) என்பதைத் தேர்வு செய்யவும்.
6. APK பொதுவாக app/build/outputs/apk/debug/app-debug.apk இடத்தில் வரும்.

App விவரங்கள்:
- தமிழ் / English labels கொண்ட வசூல் பதிவு
- பெயர் மற்றும் 10 இலக்க மொபைல் சரிபார்ப்பு
- வாரத் தவணை, வசூல் தொகை, தேதி கட்டாயம்
- மொத்த வசூல், வசூல் வரலாறு, தேடல்
- CSV export மற்றும் JSON backup/restore
- வசூல் பதிவு முடிந்ததும் SMS அனுப்பு பட்டன்
- Customer List-ல் ஒவ்வொரு வாடிக்கையாளருக்கும் SMS அனுப்பு பட்டன்
- SMS செய்தியில் பெயர், தேதி, தவணை, வசூல் மற்றும் இந்த வார மீதித் தொகை தானாக சேர்க்கப்படும்

தரவு சேமிப்பு:
- இந்த prototype தரவை Android WebView-ன் local browser storage-ல் சேமிக்கிறது.
- App uninstall அல்லது app data clear செய்தால் தரவு இழக்கப்படலாம்.
- JSON Backup-ஐ அடிக்கடி எடுத்து பாதுகாப்பாக வைக்கவும்.
- இது இன்னும் PIN login அல்லது cloud database கொண்ட பதிப்பு அல்ல.
SMS அனுப்பு அழுத்தினால் மொபைலின் SMS செயலி திறக்கும்; அனுப்புவதற்கு முன் நீங்கள் சரிபார்த்து Send அழுத்த வேண்டும். SMS உங்கள் SIM வழியாகச் செல்லும். MURUGAN FINANCE என்ற branded Sender ID-ல் SMS அனுப்ப DLT அனுமதி மற்றும் SMS gateway சேவை தனியாக தேவை.
- பல மொபைல்களில் ஒரே தரவு sync ஆகாது.

பாதுகாப்பு குறிப்பு:
வாடிக்கையாளர் நிதி விவரங்கள் உள்ளதால், உண்மையான பயன்பாட்டுக்கு முன் backup/restore, PIN பாதுகாப்பு மற்றும் தரவு பாதுகாப்பைச் சோதிக்கவும்.
