WEEKLY FINANCE ANDROID APP - SOURCE PROJECT

முக்கியம்:
இது Android Studio மூலம் APK உருவாக்குவதற்கான source project. APK file ஏற்கனவே build செய்யப்பட்டதாகக் கருத வேண்டாம்.

APK உருவாக்க:
1. கணினியில் Android Studio நிறுவவும்.
2. இந்த ZIP-ஐ extract செய்யவும்.
3. Android Studio-வில் WeeklyFinance folder-ஐ Open செய்யவும்.
4. Gradle sync முடியும் வரை காத்திருக்கவும்.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) என்பதைத் தேர்வு செய்யவும்.
6. APK பொதுவாக app/build/outputs/apk/debug/app-debug.apk இடத்தில் வரும்.

App விவரங்கள்:
- தமிழ் / English labels கொண்ட வசூல் பதிவு
- பெயர் மற்றும் 10 இலக்க மொபைல் சரிபார்ப்பு
- வாரத் தவணை, வசூல் தொகை, தேதி கட்டாயம்
- மொத்த வசூல், வசூல் வரலாறு, தேடல்
- CSV export மற்றும் JSON backup/restore

தரவு சேமிப்பு:
- இந்த prototype தரவை Android WebView-ன் local browser storage-ல் சேமிக்கிறது.
- App uninstall அல்லது app data clear செய்தால் தரவு இழக்கப்படலாம்.
- JSON Backup-ஐ அடிக்கடி எடுத்து பாதுகாப்பாக வைக்கவும்.
- இது இன்னும் PIN login அல்லது cloud database கொண்ட பதிப்பு அல்ல.
- பல மொபைல்களில் ஒரே தரவு sync ஆகாது.

பாதுகாப்பு குறிப்பு:
வாடிக்கையாளர் நிதி விவரங்கள் உள்ளதால், உண்மையான பயன்பாட்டுக்கு முன் backup/restore, PIN பாதுகாப்பு மற்றும் தரவு பாதுகாப்பைச் சோதிக்கவும்.
